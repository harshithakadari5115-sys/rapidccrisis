export type UserRole = 'guest' | 'staff' | 'admin';
export type IncidentType = 'fire' | 'medical' | 'security' | 'other';
export type IncidentStatus = 'active' | 'assigned' | 'resolved' | 'cancelled';
export type ResponderStatus = 'available' | 'busy' | 'offline';
export type TrackingStatus = 'room' | 'staff' | 'ambulance' | 'hospital';

export interface Location {
  lat: number;
  lng: number;
  room?: string;
  floor?: string;
}

export interface Profile {
  uid: string;
  displayName: string;
  email: string;
  role: UserRole;
  status?: ResponderStatus;
  location?: Location;
  currentIncidentId?: string;
}

export interface Incident {
  id: string;
  type: IncidentType;
  status: IncidentStatus;
  location: Location;
  guestId: string;
  guestName: string;
  responderIds: string[];
  priority?: 'high' | 'medium' | 'low';
  createdAt: any;
  updatedAt?: any;
  aiAdvice?: string;
  notes?: string;
}

export interface Broadcast {
  id: string;
  message: string;
  type: 'info' | 'warning' | 'danger';
  createdAt: any;
  authorId: string;
}

export interface Tracking {
  id: string;
  incidentId: string;
  status: TrackingStatus;
  updatedAt: any;
  notes?: string;
}
